import React from 'react';



export const About = ()=>{

    return(
        <>
           <div className="home_page mt-4 text-center">
    
               <h3>This is About</h3>

            </div> 
        </>

    )

}