import './assets/scss/App.scss';
import { Routes, Route, Switch, BrowserRouter as Router } from "react-router-dom";
import {Dashboard} from './components/dashboard/Dashboard';
import {Home} from './pages/Home';
import {About} from './pages/About';
import {Login} from './components/login/Login';
import {Tabform} from './components/Forms/Tabform';
import ProtectedRoutes from './routes/ProtectedRoutes';


function App() {
  return (
    <>
        <Router>
          <Routes>
            <Route  path="/"  element={<Login/>} />
             <Route element={<ProtectedRoutes/>}> 
              <Route  path="/dasboard"  element={<Dashboard/>} />
              <Route  path="/home"   element={<Home/>} />
              <Route  path="/about"  element={<About/>} />
            </Route>  
          </Routes>
        </Router>


    </>
  );
}

export default App;
