import React, {useEffect} from 'react';
import {Header} from '../header/Header';
import {Formpopup} from '../popup/Frompopup';
import ForgeviewComponent from '../view/ForgeviewComponent';
import './dashboard.scss';





export const Dashboard = ()=>{

    return  (

        <>
            <Header/>
            <div className="wrapper_content text-center">
              <div className="container=fluid">
                  <div className="col-lg-12 view_wrapper">
                    <ForgeviewComponent/>
                  </div>
              </div>  
            </div>
            {/* <Formpopup/> */}
        </>
    )
}