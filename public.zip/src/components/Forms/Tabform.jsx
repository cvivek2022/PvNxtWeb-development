import React, {useState} from  'react';
import {Tabs, 
Tab,
 Accordion,
 Form,
 Row, 
 Col,
 Button,
 Modal

} from '../../../node_modules/react-bootstrap';

import './tabform.scss';



export const Tabform = ()=>{

    return(
        <>  
            <div className="container">
                <Tabs defaultActiveKey="second">
                        <Tab eventKey="first" title="Design input">
                            <AccordinForm/>
                        </Tab>
                        <Tab eventKey="second" title="Cost Inputs">
                        Hii, I am 2nd tab content
                        </Tab>
                        <Tab eventKey="third" title="Finance Inputs">
                        Hii, I am 3rd tab content
                        </Tab>
                </Tabs>
                
            </div>
   
        </>

    )

}


export const AccordinForm = ()=>{

    return(
        <> 
         <div className="container">
         <Accordion defaultActiveKey="0">
            <Accordion.Item eventKey="0">
                <Accordion.Header >Compliance Inputs</Accordion.Header>
                <Accordion.Body>
                <Form>
                    <Row className="mb-3">
                      <Form.Group as={Col} controlId="formGridState">
                        <Form.Label>Electrical Design Code</Form.Label>
                        <Form.Select defaultValue="Choose...">
                            <option>IEC/IS</option>
                            <option>...</option>
                        </Form.Select>
                        </Form.Group>

                        <Form.Group as={Col} controlId="formGridState">
                        <Form.Label>Civil Design Code</Form.Label>
                        <Form.Select defaultValue="Choose...">
                            <option>IS/BS/ASCE</option>
                            <option>...</option>
                        </Form.Select>
                        </Form.Group>

                        <Form.Group as={Col} controlId="formGridState">
                        <Form.Label>MMS/Tracker Design</Form.Label>
                        <Form.Select defaultValue="Choose...">
                            <option>IS/Euro Code/ASCE</option>
                            <option>...</option>
                        </Form.Select>
                        </Form.Group>
                        
                    </Row>
                    <Row className="mb-3">
                      <Form.Group as={Col} controlId="formGridState">
                        <Form.Label>Earthing Design</Form.Label>
                        <Form.Select defaultValue="Choose...">
                            <option>IEC/IS</option>
                            <option>...</option>
                        </Form.Select>
                        </Form.Group>

                        <Form.Group as={Col} controlId="formGridState">
                        <Form.Label>Grid Code</Form.Label>
                        <Form.Select defaultValue="Choose...">
                            <option>Tool auto pick I/P From</option>
                            <option>...</option>
                        </Form.Select>
                        </Form.Group>
                        <Form.Group as={Col} controlId="formGridState">
          
                        </Form.Group>
                    </Row>
                    </Form>
                </Accordion.Body>
            </Accordion.Item>
            <Accordion.Item eventKey="1">
                <Accordion.Header>Radiation Source</Accordion.Header>
                <Accordion.Body>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id
                est laborum.
                </Accordion.Body>
            </Accordion.Item>
            </Accordion>
         </div>       


        </>
    )

}

