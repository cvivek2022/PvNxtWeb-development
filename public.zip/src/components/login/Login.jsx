import React, {useState, useEffect} from 'react';
import '../../assets/scss/login-form-css/login.scss';
import { Link, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios";


export const Login = () => {
 const Navigate = useNavigate(); 
  const [loading, setLoading] = useState(false);
  const [state, setState] = useState({
    email:"",
    password:""
  })

   
  useEffect(()=>{
    let token = localStorage.getItem("token")  
    if(token){
       Navigate('./dasboard');
    } else{
       Navigate('/');

    }
   }, [])



  const handleChange = (e)=>{   
    const {name,value} = e.target  
    setState({ ...state, [name]: value});   
  }
 
  

  const loginhandle = (e) =>{
    e.preventDefault();    
    const {email, password} = state;
    setLoading(true);   
    axios.post(`http://54.175.240.28/api/login`, {
      email:email,
      password:password, 
    }).then((response)=>{  
      setLoading(false);
      localStorage.setItem("token", response?.data?.accessToken);
      localStorage.setItem("user", email);
      toast.success("Login Successfull");
      Navigate('./dasboard');

    }).catch((error)=>{
      setLoading(false);  
    })
  }  
  const {email, password} = state;
    return (
        <>
        <div className="conatiner login_form_parnt">
            <div className="row flex_grid">
            <div className="col-sm-6 col-md-6 col-xs-12 login_left_wrapper">
                <div className="bg_login_content text-white">
                    <h3>Solar plant</h3> 
                    <p className="text-white">solar park, solar farm, or solar power plant is a large-scale 
                        photovoltaic system designed for the supply of merchant 
                        power into the electricity grid.</p>
                </div>

            </div>    
            <div className="col-sm-6 col-md-6 col-xs-12 login_right_wrapper ">
                <div className="login_form_wrapper text-center">
                     <h3>Hi !</h3>
                     <p>Welcome Back</p>   
                </div>
                <form className="login_form">
                    <div className="form-group ">
                      <input type="text"
                       className="form-control"
                       value={email}
                       name="email" 
                       placeholder="Email Address"
                       onChange={handleChange}
                      ></input>  
                        <input 
                        type="password"
                        className="form-control" 
                        value={password}
                        name="password"
                        placeholder="password"
                        onChange={handleChange}>
                    </input>  
                      <div className="text-center btn_form">
                          <button className="btn btn_primary_custome" onClick={loginhandle}>Login</button>
                          <Link to="/">Forgot Password</Link>
                      </div>    
                    </div>    
                </form>
                <div className="Login_footer">
                    <span>Don’t have an account</span> <Link to="#" >signup now</Link>
                </div>
            </div>   
            </div> 
        </div>  
        <ToastContainer/>
      </>
    )
}
