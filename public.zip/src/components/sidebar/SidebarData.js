import React from 'react';
import {
MdQuestionAnswer,
MdRecordVoiceOver,
MdPermContactCalendar,
MdManageAccounts,

} from "react-icons/md";

import ImgIcons from '../../assets/images';

const {logo, union, vector_stroke, unionTp, ellipse, rectangle, vectorque, scale, Vector, plus} = ImgIcons
const {rightnav} = ImgIcons

export const SidebarData = [

{
     title: '',
     path:'/',
     icon:logo,
     cName:'nav_text',

},
{
    title: '',
    path:'/page1',
    icon:unionTp,
    cName:'nav_text',

},
{
    title: '',
    path:'/about',
    icon:union,
    cName:'nav_text',

},
{
    title: '',
    path:'/',
    icon:vector_stroke,
    cName:'nav_text',

},
{
    title: '',
    path:'/p2',
    icon:ellipse,
    cName:'nav_text',

},

{
    title: '',
    path:'/p3',
    icon:rectangle,
    cName:'nav_text',

},

{
    title: '',
    path:'/p4',
    icon:vectorque,
    cName:'nav_text',

},
{
    title: '',
    path:'/p5',
    icon:scale,
    cName:'nav_text',

},

{
    title: '',
    path:'/p5',
    icon:Vector,
    cName:'nav_text',

},

{
    title: '',
    path:'/p5',
    icon:plus,
    cName:'nav_text',

},




]


export const rightsideData = [

    {
         title: '',
         path:'/',
         icon:rightnav.arrowmark,
         cName:'nav_text',
    
    },
    {
        title: '',
        path:'/page1',
        icon:rightnav.pluscircle,
        cName:'nav_text',
    
    },
    {
        title: '',
        path:'/about',
        icon:rightnav.subtractcircle,
        cName:'nav_text',
    
    },
    {
        title: '',
        path:'/login',
        icon:rightnav.squaredouble,
        cName:'nav_text',
    
    },
    {
        title: '',
        path:'/p2',
        icon:rightnav.pencil,
        cName:'nav_text',
    
    },
    
    {
        title: '',
        path:'/p3',
        icon:rightnav.squaredouble,
        cName:'nav_text',
    
    },
    
    
    
    ]

