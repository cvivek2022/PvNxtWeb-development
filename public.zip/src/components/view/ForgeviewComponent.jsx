import React, { useState, useEffect } from 'react';
import $ from "../../../node_modules/jquery";
import axios from "axios";
import { Button, Form } from '../../../node_modules/react-bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './Forgeview.scss';


const ForgeviewComponent = () => {
    const [bucketKey, setBucketKey] = useState('tyjnjhujh7');
    const [authToken, setAuthtoken] = useState('');
    const [loading, setLoading] = useState(false);
    const [dataLoad, setDataLoad] = useState(false);
    const [displyload, setDisplayLoad] = useState(false);
    const [urn, setUrn] = useState('');

    const policyKey = 'transient';
    const Autodesk = window.Autodesk;

    useEffect(() => {
        let token = localStorage.getItem("tokenview");
        if (token !== null) {
            setAuthtoken(token);
        } else {
            setAuthtoken('');
        }
        if (token === null) {
            getToken();
        }

    }, []);

    useEffect(() => {
        let user = localStorage.getItem('user');
        // let userVal = user.slice(user.length - 1);
        // setBucketKey(userVal);
        // let random = Math.random().toString(32).substring(4, bucketKey.length);
        // let random = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 5); 

        if (authToken !== null) {
            // setBucketKey(random);
            setLoading(true);
        } else {
            setLoading(false);
        }
        if (loading === true) {
            createBucket();
        }


    }, [loading, authToken]);

    useEffect(() => {
        if (dataLoad === true) {
            translateToSVF();
        }
    }, [dataLoad])

    useEffect(() => {
        if(displyload === true){
            displayViewer();
        }
    }, [displyload])

    // GET Token
    const headToken = {
        method: 'POST',
        url: 'https://developer.api.autodesk.com/authentication/v1/authenticate',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        data: 'client_id=YO6qbycCrK7l3aBX7M9yd7cFcs3dKHuf&client_secret=wiAvkV1fYIcWRYts&grant_type=client_credentials&scope=data:read data:write bucket:read viewables:read bucket:create data:create',
    };
    const getToken = () => {
        axios(headToken)
            .then(response => {
                setAuthtoken(response?.data?.access_token);
                localStorage.setItem("tokenview", response?.data?.access_token);

            }).catch(error => {
                console.log(error);
            });



    }

    // create Bucket 
    const headBucket = {
        method: 'POST',
        url: "https://developer.api.autodesk.com/oss/v2/buckets",
        headers: {
            "content-type": "application/json",
            // "x-ads-force":true,
            Authorization: "Bearer " + authToken
        },
        data: JSON.stringify({
            'bucketKey': bucketKey,
            'policyKey': policyKey
        }),
    };

    const createBucket = () => {
        axios(headBucket)
            .then(response => {
                if (response.status === 200 && response.status === 200) {
                    toast.info(`your new key -  ${response.data.bucketKey} `);
                }
            }).catch(error => {
                if (error.response.status === 401) {
                    toast.error(error.response.data.developerMessage);

                } else if (error.response.status === 409) {
                    toast.error(`your key - ${bucketKey} - ${error.response.data.reason}`);

                } else {
                    console.log(error.response);
                }
            });


    }



    //upload_file upload
    const processSelectedFiles = (e) => {
        var files = e.target.files;
        var fileName = "";


        for (var i = 0; i < files.length; i++) {
            fileName = files[i].name;
        }

        axios({
            method: 'PUT',
            url: "https://developer.api.autodesk.com/oss/v2/buckets/" + encodeURIComponent(bucketKey) + "/objects/" + encodeURIComponent(fileName) + "",
            data: files[0],
            processData: false,
            contentType: false,
            headers: {
                Authorization: "Bearer " + authToken
            },
        })
            .then(response => {
                let urn1;
                let urn2;
                urn1 = response.data.objectId;
                urn2 = btoa(urn1);
                console.log(response);
                if (response.status === 200) {
                    console.log("resolved")
                    setUrn(urn2);
                    setDataLoad(true);
                }

            }).catch(error => {
                console.log(error);
            });

    }


    const headtraslate = {
        method: 'POST',
        url: "https://developer.api.autodesk.com/modelderivative/v2/designdata/job",
        headers: {
            "content-type": "application/json",
            Authorization: "Bearer " + authToken
        },
        data: JSON.stringify({
            "input": {
                "urn": urn

            },
            "output": {
                "destination": {
                    "region": "us"
                },
                "formats": [
                    {
                        "type": "svf",
                        "views": [
                            "2d",
                            "3d"
                        ]
                    }
                ]
            }
        })
    }

    // translateToSVF File format
    const translateToSVF = () => {
        console.log("called translater");
        axios(headtraslate)
            .then(response => {
                setUrn(response.data.urn);
                setDisplayLoad(true)
            }).catch(error => {
                console.log(error);
            });
    }




    // display view
    const displayViewer = () => {
        let viewer;
        let options = {
            env: 'AutodeskProduction',
            api: 'derivativeV2',  // for models uploaded to EMEA change this option to 'derivativeV2_EU'

            getAccessToken: function (onTokenReady) {

                let token = authToken;
                let timeInSeconds = 3600; // Use value provided by Forge Authentication (OAuth) API
                onTokenReady(token, timeInSeconds);
            }
        };

        Autodesk.Viewing.Initializer(options, function () {

            let htmlDiv = document.getElementById('forgeViewer');
            viewer = new Autodesk.Viewing.GuiViewer3D(htmlDiv);
            let startedCode = viewer.start();
            if (startedCode > 0) {
                console.error('Failed to create a Viewer: WebGL not supported.');
                return;
            }

            console.log('Initialization complete, loading a model next...');

        });

        let documentId = 'urn:' + urn;
        Autodesk.Viewing.Document.load(documentId, onDocumentLoadSuccess, onDocumentLoadFailure);

        function onDocumentLoadSuccess(viewerDocument) {
            let defaultModel =  viewerDocument.getRoot().getDefaultGeometry();
             viewer.loadDocumentNode(viewerDocument, defaultModel);
        }

        function onDocumentLoadFailure() {
            console.error('Failed fetching Forge manifest');
        }

    }

    return (
        <>
            <div className="button_group_file">
                <Form.Group controlId="formFileSm" className="">
                    <Form.Control type="file" size="sm" onChange={(e) => processSelectedFiles(e)} />
                </Form.Group>
                <Button variant="custom" onClick={displayViewer}>Display viewer</Button>
            </div>

            <div id="forgeViewer"></div>
            <ToastContainer />
        </>
    )
}

export default ForgeviewComponent
