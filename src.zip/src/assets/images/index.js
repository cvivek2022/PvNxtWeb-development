const ImgIcons = {

    logo : require('./Logo.svg').default,
    union:require('./Union.svg').default,
    vector_stroke: require('./Vector_stroke.svg').default,
    unionTp: require('./Uniontp.svg').default,
    ellipse: require('./ellipse.svg').default,
    rectangle: require('./Rectangle.svg').default,
    vectorque : require('./vectorque.svg').default,
    subtract: require('./subtract.svg').default,
    subtract2: require('./subtract2.svg').default,
    scale: require('./scale.svg').default,
    Vector: require('./Vector.svg').default,
    plus : require('./plus.svg').default,
    darkMood: require('./darkMood.svg').default,
    user:require('./user.svg').default,
    notification: require('./notification.svg').default,

    country:{
        america: require('./america.png').default,
        india: require('./india.png').default,
        dubai: require('./dubai.png').default,
    },

    rightnav:{
        arrowmark: require('./arrowmark.svg').default,
        pencil: require('./pencil.svg').default,
        pluscircle: require('./pluscircle.svg').default,
        squaredouble: require('./squaredouble.svg').default,
        subtractcircle: require('./subtractcircle.svg').default,
        
    }




}

export default ImgIcons;