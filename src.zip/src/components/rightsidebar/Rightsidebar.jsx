import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { MdMenu, MdClear } from "react-icons/md";
import { rightsideData } from '../sidebar/SidebarData';
import '../../components/sidebar/Sidebar.scss';
import '../rightsidebar/Rightsidebar.scss';



export const Rightsidebar = () => {
    return (
        <>
            <nav className="nav_menu rightsidebar">
                <ul className="nav_menu_items">            
                    {rightsideData.map((item, idx) => {
                        return (
                            <li key={idx} className={item.cName}>
                                <Link to={`${item.path !== undefined ? item.path : ""}`}>
                                    <img src={item.icon} alt=""></img>
                                    <span>{item.title}</span>
                                </Link>

                            </li>
                        )
                    })}
                </ul>
            </nav>
        </>
    )
}

