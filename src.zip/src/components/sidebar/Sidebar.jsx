import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { MdMenu, MdClear } from "react-icons/md";
import { SidebarData } from './SidebarData';
import './Sidebar.scss';



export const Sidebar = (props) => {
    const {sidebar, setSiderbar} = props;
    const showSidebar = () => {
        setSiderbar(!sidebar);
    }
    return (
        <>
            <nav className={sidebar ? 'nav_menu active' : 'nav_menu'}>
                <ul className="nav_menu_items">
                    {sidebar ? (
                        
                    <li className="navbar_toggle">
                        <Link to="#" className='menu_close'>
                        <MdClear onClick={showSidebar} />
                        </Link>
                    </li> 
                        
                    ):""
                       
                    }
            
                    {SidebarData.map((item, idx) => {
                        return (
                            <li key={idx} className={item.cName}>
                                <Link to={`${item.path !== undefined ? item.path : ""}`}>
                                    <img src={item.icon} alt=""></img>
                                    <span>{item.title}</span>
                                </Link>

                            </li>
                        )
                    })}
                </ul>
            </nav>
        </>
    )
}

