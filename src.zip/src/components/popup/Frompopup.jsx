import React, {useState} from  'react';
import {Tabs, 
Tab,
 Accordion,
 Form,
 Row, 
 Col,
 Button,
 Modal

} from '../../../node_modules/react-bootstrap';
import {Tabform} from '../Forms/Tabform';
import '../popup/Formpop.scss';

export const Formpopup = () => {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  
    return (
      <>
        <Button variant="primary" onClick={handleShow}>
          Launch demo modal
        </Button>
  
        <Modal 
        size="lg"
        show={show} 
        onHide={handleClose}
        >
          <Modal.Header closeButton>
            <Modal.Title>Project Inputs page</Modal.Title>
          </Modal.Header>
          <Modal.Body>
              <Tabform/>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Previous
            </Button>
            /
            <Button variant="primary" onClick={handleClose}>
             Next
            </Button>
          </Modal.Footer>
        </Modal>
      </>
    );
  }