import React, {useState, useEffect} from 'react';
import './header.scss';
import { MdMenu, MdClear, MdArrowDropDown } from "react-icons/md";
import { Link } from 'react-router-dom';
import {Sidebar} from '../sidebar/Sidebar';
import {Rightsidebar} from '../rightsidebar/Rightsidebar'
import ImgIcons from '../../assets/images'
import {DropdownButton, Dropdown} from '../../../node_modules/react-bootstrap';


export const Header = () => {
  const{darkMood, user, notification, country} = ImgIcons  
  const [sidebar, setSiderbar] = useState(false);
  const [authuser, setAuthuser] = useState('');
  let Authuser = localStorage.getItem('user'); 
 useEffect(()=>{
    setAuthuser(Authuser);
 }, [authuser]);
  const showSidebar = () => {
      setSiderbar(!sidebar);
  }
    return (
        <>
           <header className="header_wrapper_main">
                <div className="container-fluid">
                    <div className="header_wrapper_flex">
                        <div className="hamburger_icon">
                        <Link to='#' className="menu_bar">
                            <MdMenu onClick={showSidebar} />
                        </Link>
                        </div>  
                        <div className="center_wrapper">
                           <ul>
                             <li><img src={require("../../assets/images/v2 (Stroke).svg").default} alt="head_icon"></img> </li>
                             <li><img src={require("../../assets/images/v2.svg").default} alt="head_icon"></img> </li>
                             <li><img src={require("../../assets/images/subtract.svg").default} alt="head_icon"></img> </li>
                             <li><img src={require("../../assets/images/Vectorblk.svg").default} alt="head_icon"></img> </li>
                           </ul> 
                        </div>  
                        <div className="admin_wrapper">
                            <ul>
                                <li><img src={darkMood} alt="head_icon"></img></li>
                                <li>
                                <Dropdown className="dropdown_menu">
                                    <Dropdown.Toggle variant="success" id="dropdown-basic" c>
                                    <img src={country.america} alt="country" width="24"></img>
                                    </Dropdown.Toggle>

                                    <Dropdown.Menu>
                                    <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                                    <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                                    <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>  

                                {/* <select className="form-select select_lang" aria-label="Default select example">
                                    <option selected>
                                        <img src={country.america} alt="country"></img>
                                    </option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select> */}
                                </li>
                                <li className="notiicon_main">
                                    <img src={notification} alt="head_icon"></img>
                                    <span className="notiicon">4</span>
                                </li>
                                <li><p>{Authuser}</p> <span>Admin</span></li>
                                <li><img src={user} alt="head_icon"></img></li>
    
                            </ul>
                        </div>    
                    </div>    
                </div>    
                <Sidebar sidebar={sidebar} setSiderbar={setSiderbar}/>
                <Rightsidebar/>

            </header>
        </>
    )
}
