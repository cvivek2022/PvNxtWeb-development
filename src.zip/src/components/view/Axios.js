export const headToken = {
    method: 'POST',
    url: 'https://developer.api.autodesk.com/authentication/v1/authenticate',
    headers: {
        'content-type': 'application/x-www-form-urlencoded',
    },
    data: 'client_id=YO6qbycCrK7l3aBX7M9yd7cFcs3dKHuf&client_secret=wiAvkV1fYIcWRYts&grant_type=client_credentials&scope=data:read data:write bucket:read viewables:read bucket:create data:create',
};


