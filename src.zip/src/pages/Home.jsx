import React from 'react';



export const Home = ()=>{

    return(
        <>
           <div className="home_page mt-4 text-center">
    
               <h3>Welcome to Dashboard</h3>

            </div> 
        </>

    )

}